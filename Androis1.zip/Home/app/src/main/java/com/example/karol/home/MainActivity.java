package com.example.karol.home;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.net.Uri;

public class MainActivity extends AppCompatActivity {

    public static final String COLORS = "colors";
    Button button1;

    private MediaPlayer backgroundPlayer;
    private MediaPlayer buttonPlayer;
    static public Uri[] sounds;
    public int isPlaying = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sounds = new Uri[4];
//Use parse method of the Uri class to obtain the Uri of a resource
//specified by a string
        sounds[0]  =  Uri.parse("android.resource://"  +  getPackageName()  +  "/"  + R.raw.ringd);
        sounds[1]  =  Uri.parse("android.resource://"  +  getPackageName()  +  "/"  + R.raw.ring01);
        sounds[2]  =  Uri.parse("android.resource://"  +  getPackageName()  +  "/"  + R.raw.ring02);
        sounds[3]  =  Uri.parse("android.resource://"  +  getPackageName()  +  "/"  + R.raw.ring03);
        buttonPlayer = new MediaPlayer();
        buttonPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);


        buttonPlayer.setOnPreparedListener(new MediaPlayer
                .OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
//Pause the backgroundPlayer
                backgroundPlayer.pause();
//Start the buttonPlayer
                mp.start();
            }
        });

        buttonPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                backgroundPlayer.reset();
            }
        });
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Yeeeah, push it!", Snackbar.LENGTH_LONG)
                        .setAction("onResume", null).show();
//                backgroundPlayer.pause();
                if (isPlaying == 0) {
                    backgroundPlayer.start();
                    isPlaying = 1;

                }
                else {
                    backgroundPlayer.pause();
                    isPlaying = 0;

                }
            }
        });

        button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent btnData = new Intent(getApplicationContext(), Main2Activity.class);
                startActivityForResult(btnData, 1);
            }
        });

        Button button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent btnData = new Intent(getApplicationContext(), Main2Activity.class);
                startActivityForResult(btnData, 2);
            }
        });

        Button button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent btnData = new Intent(getApplicationContext(), Main2Activity.class);
                startActivityForResult(btnData, 3);
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        backgroundPlayer.pause();
        buttonPlayer.pause();

    }

    @Override
    protected void onResume() {
        super.onResume();
        isPlaying = 1;
        backgroundPlayer = MediaPlayer.create(this, R.raw.ring01);
        backgroundPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.setLooping(true);
                mp.start();
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        backgroundPlayer.release();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == RESULT_OK) {
            int c[] = data.getIntArrayExtra(COLORS);
            switch (requestCode) {
                case 1:
                    (findViewById(R.id.mainbackground)).setBackgroundColor(Color.rgb(c[0],c[1],c[2]));
                    break;
                case 2:
                    (findViewById(R.id.button2)).setBackgroundColor(Color.rgb(c[0],c[1],c[2]));
                    (findViewById(R.id.button1)).setBackgroundColor(Color.rgb(c[0],c[1],c[2]));
                    (findViewById(R.id.button3)).setBackgroundColor(Color.rgb(c[0],c[1],c[2]));
                    break;
                case 3:
                    ((Button)findViewById(R.id.button2)).setTextColor(Color.rgb(c[0],c[1],c[2]));
                    ((Button)findViewById(R.id.button1)).setTextColor(Color.rgb(c[0],c[1],c[2]));
                    ((Button)findViewById(R.id.button3)).setTextColor(Color.rgb(c[0],c[1],c[2]));
                    break;
            }
        }
        else if (resultCode == RESULT_CANCELED);

    }
}

