package com.example.karol.home;

        import android.content.Intent;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;

public class Main2Activity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

    }

    public void onButtonOkClicked(View v) {
        EditText textB = (EditText) findViewById(R.id.editTextB);
        EditText textR = (EditText) findViewById(R.id.editTextR);
        EditText textG = (EditText) findViewById(R.id.editTextG);
        int R, G, B = 0;
        B = Integer.parseInt(textB.getText().toString());
        R = Integer.parseInt(textR.getText().toString());
        G = Integer.parseInt(textG.getText().toString());
        int[] colors = {R, G, B};

        Intent data = new Intent();
        data.putExtra(MainActivity.COLORS, colors);
        setResult(RESULT_OK, data);
        finish();
    }

    public void onButtonCancelClicked(View v) {

        setResult(RESULT_CANCELED);
        finish();
    }
}